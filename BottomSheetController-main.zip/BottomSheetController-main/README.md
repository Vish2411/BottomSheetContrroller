# BottomSheetController
UIKit component containing supplementary content that are anchored to the bottom of the screen.

![Screen Shot 2022-05-27 at 3 53 41 PM](https://user-images.githubusercontent.com/38990640/170681948-d3804a25-5b26-44ca-b197-cd19d54402b4.png)

https://user-images.githubusercontent.com/38990640/170683057-42315bba-4dc7-47d8-8d2b-c5f3415b6147.mp4

